clc;

% % Slocum
% a = 0.75; 
% b = 0.11;
% c = 0.11;
% r = 0.11;
% d = 0.22;
% l_t = 1.5;

% Laboratory Glider
a = 0.57;
b = 0.07;
c = 0.07;
r = 0.07;
d = 0.14;
l_t = 1.14;

rho = 1000; % density of surrounding fluid

% Added mass of ship structures (Page 81)
% syms x;
% f1 = a*b*c/((a^2 + x)*((a^2 + x)*(b^2 + x)*(c^2 + x))^0.5);
% f2 = a*b*c/((b^2 + x)*((a^2 + x)*(b^2 + x)*(c^2 + x))^0.5);
% f3 = a*b*c/((c^2 + x)*((a^2 + x)*(b^2 + x)*(c^2 + x))^0.5);
% 
% I1 = int(f1, 0, inf);
% I2 = int(f2, 0, inf);
% I3 = int(f3, 0, inf);
% 
% A0 = vpa(I1,3);
% B0 = vpa(I2,3);
% C0 = vpa(I3,3);
% 
% m11 = double(((4/3)*pi*rho*a*b*c*A0/(2 - A0)))*2;
% m22 = double(((4/3)*pi*rho*a*b*c*B0/(2 - B0)))*2;
% m33 = double(((4/3)*pi*rho*a*b*c*C0/(2 - C0)))*2;
% % m44 = round(((4*pi*rho/15)*(a*b*c*((b^2 - c^2)^2)*(C0 - B0))/(2*(b^2 - c^2) + (B0 - C0)*(b^2 + c^2)))*1000)/1000
% m55 = double((4*pi*rho/15)*(a*b*c*((a^2 - c^2)^2)*(A0 - C0))/(2*(c^2 - a^2) + (C0 - A0)*(c^2 + a^2)))*2;
% m66 = double((4*pi*rho/15)*(a*b*c*((a^2 - b^2)^2)*(B0 - A0))/(2*(a^2 - b^2) + (A0 - B0)*(a^2 + b^2)))*2;

% Cylinder 
% Newman  Pg. 144 eqn 132
% m22 = (rho*pi*r*r*l_m);
% m33 = (rho*pi*r*r*l_m);

% Newman 1977
% Marine Hydrodynamics
% Page 147
% https://books.google.co.in/books?id=nj-k_lAmaBYC&pg=PA144&lpg=PA144&dq=added+mass+of+cylinder&source=bl&ots=HVN9CH9bIW&sig=FCRQhKPYNtDb_DKmzU_sto7jp5k&hl=en&sa=X&ei=B7iWVOHBCsygugTa_YDgCQ&ved=0CBsQ6AEwADgK#v=onepage&q=added%20mass%20of%20cylinder&f=false
m11 = 0.065*(4/3)*pi*rho*a*(b^2)*2;
m22 = 0.90*(4/3)*pi*rho*a*(b^2)*2;
m33 = 0.90*(4/3)*pi*rho*a*(b^2)*2;
m44 = 0.70*(4/15)*pi*rho*a*(b^2)*(b^2 + c^2)*2;
m55 = 0.70*(4/15)*pi*rho*a*(b^2)*(c^2 + a^2)*2;
m66 = 0.70*(4/15)*pi*rho*a*(b^2)*(a^2 + b^2)*2;

% Added mass of fin
mfin11 = 0;
mfin22 = 0;
span = 0.55;
c = 0.134;
x = [0:0.001:c];
y = 5*0.12*c*(0.2969*((x/c).^0.5) - 0.1260*(x/c) - 0.3516*((x/c).^2) + 0.2843*((x/c).^3) - 0.1015*((x/c).^4));
area = trapz(x,y)*2;
vol = area*span;
mfin33 = vol*rho*2; % two wings

% Matrices
Mf = [m11 + mfin11       0               0
      0                  m22 + mfin22    0
      0                  0               m33 + mfin33]
 
Jxx = 0.22; % This should be hull inertia only
Jyy = 1.22; % This should be hull inertia only
Jzz = 1.22; % This should be hull inertia only

% Total inertia = 
%    hull inertia (by virtue of body mass)
%    + added hull inertia (due to volume/mass of water displaced by hull)
%    + added fin inertia (due to volume/mass of water displaced by fin)
%    + added rudder inertia (due to volume/mass of water displaced by rudder)

Jfin11 = mfin33*(span/2 + d/2)^2;
Jfin22 = 0; % nearly zero
Jfin33 = 0; % (plane of the fin) neary zero 

J = [m44 + Jxx + Jfin11       0                     0
     0                        m55 + Jyy + Jfin22    0
     0                        0                     m66 + Jzz + Jfin33]

 % Prestero thesis Page 28   
% (don't multiply by 2)
% alpha = 0.030087;
% beta = 0.2342;
% m11 = (4/3)*pi*rho*alpha*(l_t/2)*((d/2)^2);

% Ques:
% Axes configuration
% Hull inertia
% Problem with coeffs
% Hull only mass separate * Wing mass separate * Rudder mass
% Hull thickness
% Wing volume
% Rudder volume

