-mb_d*rb1
-tan(theta_d)*(mbar*rp3 + ms*rs3 + mb*rb3)
(1/(g*cos(theta_d)))*((mf3 - mf1)*v1_d*v3_d + (KM0 + KM*alpha_d)*(V_d^2))
(-mb_d*rb1 - tan(theta_d)*(mbar*rp3 + ms*rs3 + mb*rb3) + (1/(g*cos(theta_d)))*((mf3 - mf1)*v1_d*v3_d + (KM0 + KM*alpha_d)*(V_d^2)))
(1/(mbar + lambda*ms))
rp1_d = (1/(mbar + lambda*ms))*(-mb_d*rb1 -tan(theta_d)*(mbar*rp3 + ms*rs3 + mb*rb3) + (1/(g*cos(theta_d)))*((mf3 - mf1)*v1_d*v3_d + (KM0 + KM*alpha_d)*(V_d^2)))

% Downward
% ans =
%    -0.0613
% ans =
%     0.0203
% ans =
%    -0.0133
% ans =
%    -0.0543
% ans =
%     1.3514
% rp1_d =
%    -0.0733

% Upward
% ans =
%    -0.0247
% ans =
%    -0.0203
% ans =
%     0.0135
% ans =
%    -0.0315
% ans =
%     1.3514
% rp1_d =
%    -0.0426

%% SLOCUM
% Downward
% ans =
%    -0.4189
% ans =
%     0.1908
% ans =
%    -0.0123
% ans =
%    -0.2404
% ans =
%     0.0833
% rp1_d =
%    -0.0200
   
% Upward
% ans =
%    -0.3811
% ans =
%    -0.1908
% ans =
%     0.0123
% ans =
%    -0.5596
% ans =
%     0.0833
% rp1_d =
%    -0.0466