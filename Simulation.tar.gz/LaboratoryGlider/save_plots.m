
h = figure;
set(h, 'Position', [100 0 700 150]);



% Depth
plot(t, r(:,3));
set(gca,'YDir','reverse');
ylabel('Depth (m)');
xlabel('Time (Seconds)');
hgexport(gcf, 'depth.jpg', hgexport('factorystyle'), 'Format', 'jpeg');

% Pitch angle
plot(t, r(:,29)*180/pi);
ylabel('$\theta$ (deg)','interpreter','latex');
xlabel('Time (Seconds)');
hgexport(gcf, 'pitch.jpg', hgexport('factorystyle'), 'Format', 'jpeg');

% Omega_2
plot(t,r(:,5)*180/pi);
ylabel('$\Omega_2$ (deg/s)','interpreter','latex');
xlabel('Time (Seconds)');
hgexport(gcf, 'omega2.jpg', hgexport('factorystyle'), 'Format', 'jpeg');

% Velocity
V = (r(:,7).^2 + r(:,9).^2).^0.5;
plot(t,V);
ylabel('Velocity (m/s)');
xlabel('Time (Seconds)');
hgexport(gcf, 'velocity.jpg', hgexport('factorystyle'), 'Format', 'jpeg');

% Angle of attack
alpha = atan(r(:,9)./r(:,7))*180/pi;
plot(t,alpha);
xlabel('Time (Seconds)');
ylabel('$\alpha$ (deg)','interpreter','latex');
hgexport(gcf, 'alpha.jpg', hgexport('factorystyle'), 'Format', 'jpeg');

% Ballast mass
buoyancy = mh + mw + r(:,28) + ms + mbar - m;
plot(t, buoyancy*1000);
ylabel('m_0 (g)');
xlabel('Time (Seconds)');
hgexport(gcf, 'ballast_mass.jpg', hgexport('factorystyle'), 'Format', 'jpeg');

% Ballast rate
delta_mb = r(2:end,28) - r(1:end-1, 28);
delta_t  = t(2:end) - t(1:end-1)
der = delta_mb./delta_t;
plot(t(1:end-1), der*1000);
ylabel('Ballast rate (kg/s)');
xlabel('Time (Seconds)');
hgexport(gcf, 'ballast_rate.jpg', hgexport('factorystyle'), 'Format', 'jpeg');

% rp1
% rp1 = r(:,10);
% del_rp1 = r(2:end,10) - r(1:end-1,10);
% delta_t  = t(2:end) - t(1:end-1);
% rp1_v = del_rp1./delta_t;
% del_rp1_v = rp1_v(2:end) - rp1_v(1:end-1);
% delta_t  = t(3:end) - t(1:end-2);
% accl = del_rp1_v./delta_t;
% plot(t(3:end), accl);
plot(t, r(:,10));
ylabel('r_{p_1} (m)');
xlabel('Time (Seconds)');
hgexport(gcf, 'rp1.jpg', hgexport('factorystyle'), 'Format', 'jpeg');

% rs1
plot(t, r(:,13));
ylabel('r_{s_1} (m)');
xlabel('Time (Seconds)');
hgexport(gcf, 'rs1.jpg', hgexport('factorystyle'), 'Format', 'jpeg');

% Glide path
plot(r(:,1), r(:,3));
set(gca,'YDir','reverse');
ylabel('z (m)');
xlabel('x (m)');
hgexport(gcf, 'xz.jpg', hgexport('factorystyle'), 'Format', 'jpeg');
