clc;
xi_d = -38:-0.011:-100;
xi_d = deg2rad(xi_d);
xi_d = -38;
% CArr =  [175 -0.03538*100 4.57 2.8304];
CArr = [3.538 -0.03538 0.02476 2.8304];  % LG
% CArr = [132.5 0 25 2.15];

KL  = CArr(1);
KL0 = CArr(2);
KD  = CArr(3);
KD0 = CArr(4);

alpha_d = (1/2).*(KL/KD).*(tan(xi_d)).*(-1 + nthroot(1 - 4.*(KD/(KL^2)).*(cot(xi_d)).*(KD0*cot(xi_d) + KL0),2));
plot(rad2deg(alpha_d), rad2deg(xi_d));
xlabel('alpha');
ylabel('glide angle');

alpha = -10:0.01:10;
% alpha = deg2rad(alpha);
rho = 1000;
S = 0.7076;

CD = (2/(rho*S)).*(KD0 + KD.*(alpha.^2));
plot(alpha,CD);
xlabel('alpha');
ylabel('CD');

% CL = (2/(rho*S)).*(KL0 + KL.*(alpha));
% plot(alpha,CD);
% xlabel('alpha');
% ylabel('CL');
%  
% CL = 11.76.*alpha + 4.6.*alpha.*abs(alpha);
% plot(alpha,CD);
% xlabel('alpha');
% ylabel('CL');


% CFD performed on entire hull + wing or only hull? Obviously entire
% Surface area used to calculate KD from CD - 0.70 or 0.44?
